
public class Father {
	private int money = 100;  //˽��
	long mobile = 13999999999L;
	
	public void hello()	{
		System.out.println("hello");
	}
}
