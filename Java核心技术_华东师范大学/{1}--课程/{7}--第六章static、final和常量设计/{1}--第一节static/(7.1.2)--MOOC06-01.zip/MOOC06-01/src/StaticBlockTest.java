
public class StaticBlockTest {

	public static void main(String[] args) {
		System.out.println("000000000000000");
		// TODO Auto-generated method stub
		StaticBlock obj1 = new StaticBlock();
		StaticBlock obj2 = new StaticBlock();
	}

}
