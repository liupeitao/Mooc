import cn.edu.ecnu.PackageExample;

public class PackageExampleTest {

	public static void main(String[] args) {
		//����MOOC07-01.jar�е�PackageExample
		PackageExample obj = new PackageExample(); 

	}

}
