package test1;

public class A {
	private int v1 = 1;
	int v2 = 2;
	protected int v3 = 3;
	public int v4 = 4;
	
	private void showV1() 
	{
		System.out.println(v1);
	}
	void showV2()
	{
		System.out.println(v2);
	}
	protected void showV3()
	{
		System.out.println(v3);
	}
	public void showV4()
	{
		System.out.println(v4);
	}
}
