
public class Human {
	int height;    
    int weight;
    
    public void eat()  {
    	System.out.println("I can eat!");
    }
}
