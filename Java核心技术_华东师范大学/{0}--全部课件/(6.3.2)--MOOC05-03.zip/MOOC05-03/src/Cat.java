
public class Cat implements Animal
{
	public void eat() {
		System.out.println("Cat: I can eat");
	}
	
	public void move(){
		System.out.println("Cat: I can move");
	}
}
