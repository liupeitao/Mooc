
public class Dog implements Animal
{
	public void eat() {
		System.out.println("Dog: I can eat");
	}
	
	public void move() {
		System.out.println("Dog: I can move");
	}
}
