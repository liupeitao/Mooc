package a;

public class Man {

}
