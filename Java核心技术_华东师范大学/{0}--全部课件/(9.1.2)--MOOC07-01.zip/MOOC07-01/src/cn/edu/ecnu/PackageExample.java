//cn/edu/ecnu/PackageExample.java

package cn.edu.ecnu;
public class PackageExample 
{
}
