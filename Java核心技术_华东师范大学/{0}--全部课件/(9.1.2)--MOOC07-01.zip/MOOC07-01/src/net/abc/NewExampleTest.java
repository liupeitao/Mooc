package net.abc;

import com.test.NewExample;

public class NewExampleTest {
	public static void main(String[] a)
	{
		new NewExample().hello();
	}
}
