package c;

import a.Man;



public class Test {

	public static void main(String[] args) {
		Man m = new Man();
		b.Man m2 = new b.Man();
	}

}
