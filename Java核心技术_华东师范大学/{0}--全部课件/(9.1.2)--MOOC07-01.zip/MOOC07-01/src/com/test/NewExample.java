package com.test;

public class NewExample {
	public void hello()
	{
		System.out.println("hello");
	}
}
