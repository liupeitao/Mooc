package b;

public class Man {

}
