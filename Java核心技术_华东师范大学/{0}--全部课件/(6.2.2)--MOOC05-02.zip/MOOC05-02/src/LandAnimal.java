
public abstract class LandAnimal implements Animal {

	public abstract void eat() ;

	public void move() {
		System.out.println("I can walk by feet");
	}
}
