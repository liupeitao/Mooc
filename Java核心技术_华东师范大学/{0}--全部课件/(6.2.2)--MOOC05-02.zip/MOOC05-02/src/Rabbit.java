
public class Rabbit extends LandAnimal implements ClimbTree {

	public void climb() {
		System.out.println("Rabbit: I can climb");		
	}

	public void eat() {
		System.out.println("Rabbit: I can eat");		
	}
}
