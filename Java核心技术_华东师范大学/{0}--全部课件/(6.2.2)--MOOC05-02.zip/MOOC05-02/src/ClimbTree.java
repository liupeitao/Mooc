
public interface ClimbTree {
	public void climb();
}
