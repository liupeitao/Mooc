
public interface Animal {
	public void eat();
	public void move();
}
