
public class ArgumentTest 
{
	public static void main(String[] args) 
	{
		for(int i=0;i<args.length;i++)
		{
			//���ν��β����
			System.out.println(args[i]);
		}
	}
}
