
public class FinalMethodFather {
	public final void f1()
	{
		
	}
}
