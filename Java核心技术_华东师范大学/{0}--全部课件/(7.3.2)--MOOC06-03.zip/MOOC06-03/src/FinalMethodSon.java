
public class FinalMethodSon extends FinalMethodFather{
	public void f1()
	{
		
	}
}
