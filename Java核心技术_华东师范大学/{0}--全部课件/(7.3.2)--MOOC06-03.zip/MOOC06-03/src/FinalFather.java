
final public class FinalFather {

}
class Son1 extends FinalFather
{
	
}