
public class FinalPrimitiveType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int a = 5;
		a=10;
	}

}
