package com.coin.concept;

/**
 * Workable 可工作能力的接口
 * @author Tom
 *
 */
public interface Workable {
	void work();
}
