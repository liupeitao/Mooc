
public class Father {
	public void f1() throws ArithmeticException
	{
		
	}
}
