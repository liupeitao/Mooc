
public class Woman extends Human {
	public void weave()
	{
		System.out.println("I can weave");
	}//֯��
}
