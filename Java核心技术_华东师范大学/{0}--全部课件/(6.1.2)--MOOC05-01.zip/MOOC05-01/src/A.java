
public class A {
	public A()
	{
		System.out.println("111111");
	}
	public A(int a)
	{
		System.out.println("222222");
	}
}
