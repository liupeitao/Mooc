
public class Father 
{
	public void f1() 
	{
		System.out.println("hi");
	}
}
