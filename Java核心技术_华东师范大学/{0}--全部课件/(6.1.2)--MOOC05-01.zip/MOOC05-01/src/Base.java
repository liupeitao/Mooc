
public class Base {
	private int num = 10;
	
	public int getNum()
	{
		return this.num;
	}
}
