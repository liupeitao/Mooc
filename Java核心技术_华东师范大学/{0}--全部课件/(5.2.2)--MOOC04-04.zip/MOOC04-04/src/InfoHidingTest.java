
public class InfoHidingTest {
	public static void main(String[] args) {
		InfoHiding obj = new InfoHiding(100);
		obj.setId(200);
		System.out.println(obj.getId());
	}
}
