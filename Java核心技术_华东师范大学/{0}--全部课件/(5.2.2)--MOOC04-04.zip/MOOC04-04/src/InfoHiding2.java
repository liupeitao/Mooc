
public class InfoHiding2 {
	private int id;
	
	public InfoHiding2(int id)
	{
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
