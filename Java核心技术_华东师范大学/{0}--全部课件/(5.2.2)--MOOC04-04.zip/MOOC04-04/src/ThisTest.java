
public class ThisTest {

	public static void main(String[] args) {
		MyPairNumber obj = new MyPairNumber(5);
				
		System.out.println(obj.sum());
	}

}
