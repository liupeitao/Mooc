
class InfoHiding {
	private int id;

	public InfoHiding(int id2) {
		id = id2;
	}
	public int getId() {
		return id;
	}
	public void setId(int id2) {
		id = id2;
	}
}
