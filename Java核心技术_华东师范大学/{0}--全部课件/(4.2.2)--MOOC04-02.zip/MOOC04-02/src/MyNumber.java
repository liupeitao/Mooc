class MyNumber
{
	int num = 5; 
}