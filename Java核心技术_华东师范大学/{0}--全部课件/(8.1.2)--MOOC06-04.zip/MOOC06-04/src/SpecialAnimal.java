
public interface SpecialAnimal {
	String color = "yellow"; //default: public static final
	public void move();
}
