
public class A {
	public Integer num = 100;
	public Integer num2 = 128;
	public Character c = 100;
}
