
public class Constants {
	public final static double PI_NUMBER = 3.14;
	public static final String DEFAULT_COUNTRY="China";
	
	public static void main(String[] a)
	{
		System.out.println(Constants.PI_NUMBER);
		System.out.println(Constants.DEFAULT_COUNTRY);
	}
}
